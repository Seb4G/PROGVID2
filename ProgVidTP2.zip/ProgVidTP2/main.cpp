#include <SFML/Graphics.hpp>

using namespace sf;

const int anchoFrame = 100;
const int altoFrame = 110;
const int idleFrames[] = { 1, 2, 3 };
const int caminarCostadoFrames[] = { 4, 5, 6, 7 };
const int caminarAtrasFrames[] = { 10, 11 };
const int caminarAdelanteFrames[] = { 8, 9 };
const int saltoFrames[] = { 13, 14, 15, 16 };
const int caidaFrame = 16;

enum class AnimationState {
    Idle,
    CaminarCostado,
    CaminarAtras,
    CaminarAdelante,
    Salto,
    Caida
};

class Mario {
public:
    Mario() {
        texturaMario.loadFromFile("assets/spritesheet.png");
        spriteMario.setTexture(texturaMario);
        spriteMario.setTextureRect(IntRect((idleFrames[0] - 1) * anchoFrame, 0, anchoFrame, altoFrame));
        estadoAnimacion = AnimationState::Idle;
        frameActual = 0;
        duracionFrame = 0.2f;
        posicionInicial = Vector2f(400, 415);
        posicion = posicionInicial;
        saltando = false;
        saltoInicio = false;
        alturaSalto = 120.f;
        velocidadSalto = 0.1f;
        velocidadCaida = 0.2f;
        progresoSalto = 0.0f;
    }

    void actualizarPos(float tiempoTranscurrido, FloatRect bloqueBounds) {
        if (clock.getElapsedTime().asSeconds() > duracionFrame) {
            actualizarAnimacion();
            clock.restart();
        }
        if (saltando || estadoAnimacion == AnimationState::Caida) {
            manejarSalto(bloqueBounds);
        }
        spriteMario.setPosition(posicion);
    }

    void manejarEventos(Event evt) {
        if (evt.type == Event::KeyPressed && evt.key.code == Keyboard::Space && !saltando) {
            estadoAnimacion = AnimationState::Salto;
            saltando = true;
            saltoInicio = true;
            progresoSalto = 0.0f;
        }
        if (!saltando) {
            if (Keyboard::isKeyPressed(Keyboard::A)) {
                posicion.x -= 0.1f;
                estadoAnimacion = AnimationState::CaminarCostado;
            }
            else if (Keyboard::isKeyPressed(Keyboard::D)) {
                posicion.x += 0.1f;
                estadoAnimacion = AnimationState::CaminarCostado;
            }
            else if (Keyboard::isKeyPressed(Keyboard::S)) {
                estadoAnimacion = AnimationState::CaminarAtras;
            }
            else if (Keyboard::isKeyPressed(Keyboard::W)) {
                estadoAnimacion = AnimationState::CaminarAdelante;
            }
            else {
                estadoAnimacion = AnimationState::Idle;
            }
        }
    }

    void dibujar(RenderWindow& ventana) {
        ventana.draw(spriteMario);
    }

private:
    Texture texturaMario;
    Sprite spriteMario;
    AnimationState estadoAnimacion;
    Clock clock;
    Vector2f posicion;
    Vector2f posicionInicial;
    int frameActual;
    bool saltando;
    bool saltoInicio;
    float duracionFrame;
    float alturaSalto;
    float velocidadSalto;
    float velocidadCaida;
    float progresoSalto;

    void actualizarAnimacion() {
        switch (estadoAnimacion) {
        case AnimationState::Idle:
            frameActual = (frameActual + 1) % (sizeof(idleFrames) / sizeof(idleFrames[0]));
            spriteMario.setTextureRect(IntRect((idleFrames[frameActual] - 1) * anchoFrame, 0, anchoFrame, altoFrame));
            break;
        case AnimationState::CaminarCostado:
            frameActual++;
            spriteMario.setTextureRect(IntRect((caminarCostadoFrames[frameActual % (sizeof(caminarCostadoFrames) / sizeof(caminarCostadoFrames[0]))] - 1) * anchoFrame, 0, anchoFrame, altoFrame));
            break;
        case AnimationState::CaminarAtras:
            frameActual++;
            spriteMario.setTextureRect(IntRect((caminarAtrasFrames[frameActual % (sizeof(caminarAtrasFrames) / sizeof(caminarAtrasFrames[0]))] - 1) * anchoFrame + 10, 0, anchoFrame, altoFrame));
            break;
        case AnimationState::CaminarAdelante:
            frameActual++;
            spriteMario.setTextureRect(IntRect((caminarAdelanteFrames[frameActual % (sizeof(caminarAdelanteFrames) / sizeof(caminarAdelanteFrames[0]))] - 1) * anchoFrame, 0, anchoFrame, altoFrame));
            break;
        case AnimationState::Salto:
            frameActual++;
            spriteMario.setTextureRect(IntRect((saltoFrames[frameActual % (sizeof(saltoFrames) / sizeof(saltoFrames[0]))] - 1) * anchoFrame + 52, 0, anchoFrame, altoFrame + 40));
            break;
        case AnimationState::Caida:
            spriteMario.setTextureRect(IntRect((caidaFrame - 1) * anchoFrame + 52, 0, anchoFrame, altoFrame + 40));
            break;
        }
    }

    void manejarSalto(FloatRect bloqueBounds) {
        if (saltoInicio) {
            progresoSalto += velocidadSalto;
            if (progresoSalto < alturaSalto) {
                posicion.y -= velocidadSalto;
            }
            else if (progresoSalto < 2 * alturaSalto) {
                posicion.y += velocidadSalto;
            }
            else {
                saltando = false;
                saltoInicio = false;
                estadoAnimacion = AnimationState::Caida;
                progresoSalto = 0.0f;  // Reiniciar el progreso del salto para la ca�da
            }

            if (spriteMario.getGlobalBounds().intersects(bloqueBounds)) {
                estadoAnimacion = AnimationState::Caida;
                saltoInicio = false;
                progresoSalto = 0.0f;  // Reiniciar el progreso del salto para la ca�da
            }
        }
        else if (estadoAnimacion == AnimationState::Caida) {
            posicion.y += velocidadCaida;
            if (posicion.y >= posicionInicial.y) {
                posicion.y = posicionInicial.y;
                estadoAnimacion = AnimationState::Idle;
                saltando = false;  // Permitir que Mario vuelva a saltar
            }
        }
    }
};

class BloquePared {
public:
    BloquePared() {
        texturaBloque.loadFromFile("assets/bloque_pared.png");
        spriteBloque.setTexture(texturaBloque);
        spriteBloque.setPosition(100, 300);
    }

    void dibujar(RenderWindow& ventana) {
        ventana.draw(spriteBloque);
    }

    FloatRect getBounds() {
        return spriteBloque.getGlobalBounds();
    }

private:
    Texture texturaBloque;
    Sprite spriteBloque;
};

class Fondo {
public:
    Fondo() {
        texturaFondo.loadFromFile("assets/mundo_fondo.jpg");
        spriteFondo.setTexture(texturaFondo);
    }

    void dibujar(RenderWindow& ventana) {
        ventana.draw(spriteFondo);
    }

private:
    Texture texturaFondo;
    Sprite spriteFondo;
};

int main() {
    RenderWindow App(VideoMode(800, 600), "Mario Animado");
    Event evt;
    Fondo fondo;
    Mario mario;
    BloquePared bloquePared;
    Clock reloj;

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            if (evt.type == Event::Closed) {
                App.close();
            }
            mario.manejarEventos(evt);
        }
        mario.manejarEventos(evt);
        float tiempoTranscurrido = reloj.restart().asSeconds();
        mario.actualizarPos(tiempoTranscurrido, bloquePared.getBounds());
        App.clear();
        fondo.dibujar(App);
        bloquePared.dibujar(App);
        mario.dibujar(App);
        App.display();
    }
    return 0;
}